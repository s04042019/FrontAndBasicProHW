
const result = prompt("What is the block width ?"); 
//console.log(result);
const result_1 = parseInt(result)
console.log(result_1);




